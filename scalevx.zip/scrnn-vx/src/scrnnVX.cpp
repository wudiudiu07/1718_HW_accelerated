#include <VX/vx.h>
#include <VX/vx_compatibility.h>
#include "opencv2/opencv.hpp"
#include <string>

using namespace cv;
using namespace std;

#define ERROR_CHECK_STATUS( status ) { \
        vx_status status_ = (status); \
        if(status_ != VX_SUCCESS) { \
            printf("ERROR: failed with status = (%d) at " __FILE__ "#%d\n", status_, __LINE__); \
            exit(1); \
        } \
}

#define ERROR_CHECK_OBJECT( obj ) { \
        vx_status status_ = vxGetStatus((vx_reference)(obj)); \
        if(status_ != VX_SUCCESS) { \
            printf("ERROR: failed with status = (%d) at " __FILE__ "#%d\n", status_, __LINE__); \
            exit(1); \
        } \
}

static void VX_CALLBACK log_callback(vx_context context, vx_reference ref, vx_status status, const vx_char string[])
{
    size_t len = strlen(string);
    if (len > 0) {
        printf("%s", string);
        if (string[len - 1] != '\n')
            printf("\n");
        fflush(stdout);
    }
}

double getPSNR(const Mat& I1, const Mat& I2) {
  Mat s1;
  absdiff(I1, I2, s1);       // |I1 - I2|
  s1.convertTo(s1, CV_32F);  // cannot make a square on 8 bits
  s1 = s1.mul(s1);           // |I1 - I2|^2
  Scalar s = sum(s1);        // sum elements per channel
  double sse = s.val[0] + s.val[1] + s.val[2];  // sum channels
  double rmse = sqrt(sse / (double)(I1.channels() * I1.total() * 255));

  if (rmse == 0)  // for small values    zero
    return 100;
  else {
    double psnr = 20.0 * log10(1.0 / rmse);
    return psnr;
  }
}
// copied example from the OpenCV
// https://www.ccoderun.ca/programming/doxygen/opencv_3.2.0/tutorial_gpu_basics_similarity.html
Scalar getMSSIM(const Mat& i1, const Mat& i2) {
  const double C1 = 6.5025, C2 = 58.5225;
  /***************************** INITS **********************************/
  int d = CV_32F;
  Mat I1, I2;
  i1.convertTo(I1, d);  // cannot calculate on one byte large values
  i2.convertTo(I2, d);
  Mat I2_2 = I2.mul(I2);   // I2^2
  Mat I1_2 = I1.mul(I1);   // I1^2
  Mat I1_I2 = I1.mul(I2);  // I1 * I2
  /*************************** END INITS **********************************/
  Mat mu1, mu2;  // PRELIMINARY COMPUTING
  GaussianBlur(I1, mu1, Size(11, 11), 1.5);
  GaussianBlur(I2, mu2, Size(11, 11), 1.5);
  Mat mu1_2 = mu1.mul(mu1);
  Mat mu2_2 = mu2.mul(mu2);
  Mat mu1_mu2 = mu1.mul(mu2);
  Mat sigma1_2, sigma2_2, sigma12;
  GaussianBlur(I1_2, sigma1_2, Size(11, 11), 1.5);
  sigma1_2 -= mu1_2;
  GaussianBlur(I2_2, sigma2_2, Size(11, 11), 1.5);
  sigma2_2 -= mu2_2;
  GaussianBlur(I1_I2, sigma12, Size(11, 11), 1.5);
  sigma12 -= mu1_mu2;
  Mat t1, t2, t3;
  t1 = 2 * mu1_mu2 + C1;
  t2 = 2 * sigma12 + C2;
  t3 = t1.mul(t2);  // t3 = ((2*mu1_mu2 + C1).*(2*sigma12 + C2))
  t1 = mu1_2 + mu2_2 + C1;
  t2 = sigma1_2 + sigma2_2 + C2;
  t1 = t1.mul(t2);  // t1 =((mu1_2 + mu2_2 + C1).*(sigma1_2 + sigma2_2 + C2))
  Mat ssim_map;
  divide(t3, t1, ssim_map);       // ssim_map =  t3./t1;
  Scalar mssim = mean(ssim_map);  // mssim = average of ssim map
  return mssim;
}

int main(int argc, char **argv)
{
    if (argc < 6) {
        printf("Usage:\n"
                "./scrnnVX --image <imageName> --Scale_factor <factor> --isBIC <0:1>\n");
        return 0;
    }

    
    int width = 480, height = 360;

    vx_context context = vxCreateContext();
    ERROR_CHECK_OBJECT(context);
    vxRegisterLogCallback(context, log_callback, vx_false_e);
    
    vx_graph graph = vxCreateGraph(context);
    ERROR_CHECK_OBJECT(graph);
    
    vx_int32 scale_factor = atoi(argv[4]);
    vx_image input_image = vxCreateImage(context, width/scale_factor, height/scale_factor, VX_DF_IMAGE_RGB);
    ERROR_CHECK_OBJECT(input_image);
    vx_image output_image = vxCreateImage(context,width, height, VX_DF_IMAGE_RGB);
    vx_image image_r = vxCreateVirtualImage(graph, width/scale_factor, height/scale_factor, VX_DF_IMAGE_U8);
    vx_image image_g = vxCreateVirtualImage(graph, width/scale_factor, height/scale_factor, VX_DF_IMAGE_U8);
    vx_image image_b = vxCreateVirtualImage(graph, width/scale_factor, height/scale_factor, VX_DF_IMAGE_U8);
    vx_image out_r[] = {
     vxCreateVirtualImage(graph, width, height, VX_DF_IMAGE_U8),
     vxCreateVirtualImage(graph, width, height, VX_DF_IMAGE_U8),
     vxCreateVirtualImage(graph, width, height, VX_DF_IMAGE_U8),
    		
    };
    bool isBIC = atoi(argv[6]);
    std::cout << isBIC << std::endl;
    vx_enum interpo_type = isBIC? VX_INTERPOLATION_AREA: VX_INTERPOLATION_BILINEAR;
    vx_node nodes[]= {
     vxChannelExtractNode(graph, input_image, VX_CHANNEL_R, image_r),
     vxChannelExtractNode(graph, input_image, VX_CHANNEL_G, image_g),
     vxChannelExtractNode(graph, input_image, VX_CHANNEL_B, image_b),
     vxScaleImageNode(graph, image_r,out_r[0], interpo_type),
     vxScaleImageNode(graph, image_g,out_r[1], interpo_type),
     vxScaleImageNode(graph, image_b,out_r[2], interpo_type),
     vxChannelCombineNode(graph, out_r[0],out_r[1],out_r[2],NULL, output_image)
    };

	
    for( vx_size i = 0; i < sizeof( nodes ) / sizeof( nodes[0] ); i++ )
    {
        ERROR_CHECK_OBJECT( nodes[i] );
        ERROR_CHECK_STATUS( vxReleaseNode( &nodes[i] ) );
    }

    ERROR_CHECK_STATUS( vxVerifyGraph( graph ) );
    
    string option = argv[1];
    Mat input;
    Mat input_org;
    if (option == "--image")
    {
        string imageLocation = argv[2];
        input_org = imread(imageLocation.c_str());
        if (input_org.empty()) {
           printf("Image not found\n");
           return 0;
        }
	resize(input_org, input_org, Size(width, height));
        resize(input_org, input, Size(width/scale_factor, height/scale_factor),cv::INTER_LINEAR);
        imshow("inputWindow", input_org);
        vx_rectangle_t cv_rgb_image_region;
        cv_rgb_image_region.start_x    = 0;
        cv_rgb_image_region.start_y    = 0;
        cv_rgb_image_region.end_x      = width/scale_factor;
        cv_rgb_image_region.end_y      = height/scale_factor;
        vx_imagepatch_addressing_t cv_rgb_image_layout{};
        cv_rgb_image_layout.dim_x = input.cols;
        cv_rgb_image_layout.dim_y = input.rows;
        cv_rgb_image_layout.stride_x = input.elemSize();
        cv_rgb_image_layout.stride_y = input.step;
        vx_uint8 * cv_rgb_image_buffer = input.data;
        ERROR_CHECK_STATUS( vxCopyImagePatch( input_image, &cv_rgb_image_region, 0,
                                            &cv_rgb_image_layout, cv_rgb_image_buffer,
                                            VX_WRITE_ONLY, VX_MEMORY_TYPE_HOST ) );
        ERROR_CHECK_STATUS( vxProcessGraph( graph ) );
        vx_rectangle_t rect = { 0, 0, (vx_uint32)width, (vx_uint32)height};
        vx_map_id map_id;
        vx_imagepatch_addressing_t addr;
        void * ptr;
        ERROR_CHECK_STATUS( vxMapImagePatch( output_image, &rect, 0, &map_id, &addr, &ptr,
                                            VX_READ_ONLY, VX_MEMORY_TYPE_HOST, VX_NOGAP_X ) );
        Mat mat( height, width, CV_8UC3, ptr, addr.stride_y );
	std::cout << mat.size() << " "<< input_org.size() << std::endl;
        imshow( "scaled interpo", mat );
        waitKey(0);

	double psnr = getPSNR(input_org, mat);
	std::cout << "psnr: " << psnr << std::endl;
        ERROR_CHECK_STATUS( vxUnmapImagePatch( output_image, map_id ) );
    }
    else {
        printf("Usage:\n"
                "./cannyDetect --image <imageName>\n"
                "./cannyDetect --live \n");
        return 0;
    }

    ERROR_CHECK_STATUS( vxReleaseGraph( &graph ) );
    ERROR_CHECK_STATUS( vxReleaseImage( &input_image ) );
    ERROR_CHECK_STATUS( vxReleaseImage( &output_image ) );
    ERROR_CHECK_STATUS( vxReleaseContext( &context ) );
    return 0;
}
